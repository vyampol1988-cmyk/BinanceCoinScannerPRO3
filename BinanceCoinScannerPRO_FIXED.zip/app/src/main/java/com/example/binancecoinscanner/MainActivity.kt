package com.example.binancecoinscanner

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

private const val BG = 0xFF0B1020.toInt()
private const val PANEL = 0xFF141C2F.toInt()
private const val PANEL2 = 0xFF1B2740.toInt()
private const val TEXT = 0xFFF1F5F9.toInt()
private const val MUTED = 0xFF9AA8BD.toInt()
private const val GREEN = 0xFF43D9A3.toInt()
private const val RED = 0xFFFF7185.toInt()
private const val GOLD = 0xFFFFC857.toInt()
private const val CHANNEL_ID = "scanner_signals"

private val memeAssets = setOf("DOGE","SHIB","PEPE","BONK","FLOKI","WIF","BOME","TURBO","NEIRO","NOT","BRETT","MEME","POPCAT","PENGU","TRUMP","PNUT","ACT","GOAT","MEW","MYRO","MOG","BABYDOGE","1000SATS","ORDI","CAT","WHY","BAN","CHEEMS","TOSHI","PONKE","SLERF","DEGEN","MOODENG","FWOG","HIPPO","CHILLGUY","USELESS")
private val fmt = DecimalFormat("#,##0.########")
private val num = DecimalFormat("#,##0.0")

data class CoinSignal(
    val symbol: String, val base: String, val price: Double, val score: Double,
    val h1: Double, val h4: Double, val h24: Double, val rsi: Double,
    val volumeRatio: Double, val trendUp: Boolean, val meme: Boolean, val volume24: Double
)

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var summary: TextView
    private lateinit var allTab: Button
    private lateinit var memeTab: Button
    private lateinit var scanButton: Button
    private var results: List<CoinSignal> = emptyList()
    private var showMemes = false
    private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        createNotificationChannel()
        requestNotificationPermissionIfNeeded()
        buildUi()
        renderResults()
        scan()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(18), dp(16), dp(18), dp(12)) }
        val scroll = ScrollView(this).apply { fillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        titleBox.addView(label("BINANCE", 12, GREEN, true))
        titleBox.addView(label("SCANNER PRO", 25, TEXT, true))
        titleBox.addView(label("SPOT • USDT • MARKET RADAR", 10, MUTED, true))
        header.addView(titleBox)
        val badge = label("LIVE DATA", 10, GREEN, true).apply { setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(PANEL2) }
        header.addView(badge)
        content.addView(header)
        content.addView(space(18))

        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(PANEL, 18) }
        hero.addView(label("РЫНОЧНЫЙ СКАНЕР", 12, MUTED, true))
        summary = label("Ожидание данных Binance…", 18, TEXT, true)
        hero.addView(summary)
        hero.addView(space(6))
        status = label("Подключение к публичному API…", 12, MUTED, false)
        hero.addView(status)
        hero.addView(space(14))
        scanButton = Button(this).apply { text = "СКАНИРОВАТЬ РЫНОК"; isAllCaps = false; setTextColor(BG); setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN)); textSize = 14f; setOnClickListener { scan() } }
        hero.addView(scanButton, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(hero)
        content.addView(space(14))

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        allTab = tabButton("Все монеты") { showMemes = false; updateTabs(); renderResults() }
        memeTab = tabButton("Мемкоины") { showMemes = true; updateTabs(); renderResults() }
        tabs.addView(allTab, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) })
        tabs.addView(memeTab, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(6) })
        content.addView(tabs)
        content.addView(space(14))
        content.addView(label("ЛУЧШИЕ СИГНАЛЫ", 12, MUTED, true))
        content.addView(space(8))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        content.addView(space(14))
        val disclaimer = label("Рейтинг — техническая эвристика, не прогноз и не рекомендация покупать. Первая версия не совершает сделки. Торговля будет добавляться отдельно после тестирования.", 11, MUTED, false)
        disclaimer.setPadding(dp(2), dp(8), dp(2), dp(8))
        content.addView(disclaimer)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("BINANCE PUBLIC DATA  •  NO API KEY REQUIRED", 9, MUTED, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
        setContentView(root)
        updateTabs()
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        scanButton.isEnabled = false
        scanButton.text = "СКАНИРОВАНИЕ…"
        status.text = "Получаем рынок и анализируем свечи. Это может занять минуту."
        executor.execute {
            try {
                val found = performScan()
                runOnUiThread {
                    results = found.sortedByDescending { it.score }
                    scanning = false
                    scanButton.isEnabled = true
                    scanButton.text = "СКАНИРОВАТЬ ЕЩЁ РАЗ"
                    val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                    status.text = "Обновлено $stamp • ${results.size} монет • публичные данные"
                    summary.text = "Найдено ${results.count { it.score >= 60 }} сигналов с рейтингом 60+"
                    renderResults()
                    notifyTopSignals(results.filter { it.score >= 80 }.take(3))
                }
            } catch (e: Exception) {
                runOnUiThread {
                    scanning = false
                    scanButton.isEnabled = true
                    scanButton.text = "ПОВТОРИТЬ СКАНИРОВАНИЕ"
                    status.text = "Ошибка соединения: ${e.message ?: "проверь интернет"}"
                    summary.text = "Не удалось загрузить данные"
                    Toast.makeText(this, "Сканирование не удалось. Попробуй ещё раз.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performScan(): List<CoinSignal> {
        val info = JSONObject(get("/api/v3/exchangeInfo"))
        val allowed = HashSet<String>()
        val symbols = info.getJSONArray("symbols")
        for (i in 0 until symbols.length()) {
            val s = symbols.getJSONObject(i)
            if (s.optString("status") == "TRADING" && s.optString("quoteAsset") == "USDT" && s.optBoolean("isSpotTradingAllowed", true)) allowed.add(s.optString("symbol"))
        }
        val tickers = JSONArray(get("/api/v3/ticker/24hr"))
        val candidates = mutableListOf<Pair<String, Double>>()
        for (i in 0 until tickers.length()) {
            val t = tickers.getJSONObject(i)
            val symbol = t.optString("symbol")
            if (!allowed.contains(symbol) || !symbol.endsWith("USDT")) continue
            val base = symbol.removeSuffix("USDT")
            if (listOf("UP", "DOWN", "BULL", "BEAR").any { base.contains(it) }) continue
            val vol = t.optDouble("quoteVolume", 0.0)
            if (vol >= 1_000_000.0) candidates.add(symbol to vol)
        }
        val tickerBySymbol = HashMap<String, JSONObject>()
        for (i in 0 until tickers.length()) tickerBySymbol[tickers.getJSONObject(i).optString("symbol")] = tickers.getJSONObject(i)
        val selected = candidates.sortedByDescending { it.second }.take(35)
        val out = mutableListOf<CoinSignal>()
        selected.forEachIndexed { index, item ->
            runOnUiThread { status.text = "Анализ ${index + 1}/${selected.size}: ${item.first}" }
            try {
                val candles = JSONArray(get("/api/v3/klines?symbol=${item.first}&interval=1h&limit=60"))
                if (candles.length() < 30) return@forEachIndexed
                val closes = mutableListOf<Double>(); val volumes = mutableListOf<Double>(); val highs = mutableListOf<Double>(); val lows = mutableListOf<Double>()
                // The final candle may still be forming; exclude it for indicator calculations.
                for (i in 0 until candles.length() - 1) {
                    val c = candles.getJSONArray(i)
                    closes.add(c.optString(4).toDoubleOrNull() ?: 0.0)
                    highs.add(c.optString(2).toDoubleOrNull() ?: 0.0)
                    lows.add(c.optString(3).toDoubleOrNull() ?: 0.0)
                    volumes.add(c.optString(7).toDoubleOrNull() ?: 0.0)
                }
                if (closes.size < 25 || closes.last() <= 0) return@forEachIndexed
                val price = closes.last()
                val h1 = pct(closes.last(), closes[closes.lastIndex - 1])
                val h4 = pct(closes.last(), closes[closes.lastIndex - 4])
                val ema9 = ema(closes, 9); val ema21 = ema(closes, 21)
                val rsi = rsi(closes, 14)
                val recent = volumes.takeLast(5).average()
                val prior = volumes.subList(max(0, volumes.size - 25), max(0, volumes.size - 5)).average().let { if (it.isNaN()) 0.0 else it }
                val ratio = if (prior > 0) recent / prior else 0.0
                var score = min(25.0, max(0.0, h4 * 2.5))
                val trend = ema9 > ema21
                if (trend) score += 20.0
                score += min(25.0, max(0.0, (ratio - 1.0) * 12.5))
                score += min(15.0, max(0.0, h1 * 3.0))
                if (rsi in 50.0..68.0) score += 15.0 else if (rsi in 42.0..50.0 || rsi > 68.0 && rsi <= 75.0) score += 8.0 else if (rsi > 82.0) score -= 10.0
                val ticker = tickerBySymbol[item.first]
                val base = item.first.removeSuffix("USDT")
                out.add(CoinSignal(item.first, base, price, min(100.0, max(0.0, score)), h1, h4, ticker?.optDouble("priceChangePercent", 0.0) ?: 0.0, rsi, ratio, trend, memeAssets.contains(base), item.second))
                Thread.sleep(90)
            } catch (_: Exception) { /* Skip individual pair; continue scanning. */ }
        }
        if (out.isEmpty()) throw IllegalStateException("Binance не вернул данные для анализа")
        return out
    }

    private fun renderResults() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val filtered = results.filter { !showMemes || it.meme }
        if (filtered.isEmpty()) {
            list.addView(label(if (showMemes) "Мемкоины появятся после завершения сканирования." else "Нажми кнопку, чтобы загрузить рынок." , 13, MUTED, false).apply { setPadding(dp(10), dp(20), dp(10), dp(20)) })
            return
        }
        filtered.take(40).forEach { coin -> list.addView(coinCard(coin)); list.addView(space(8)) }
    }

    private fun coinCard(c: CoinSignal): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)); background = rounded(PANEL, 14) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val nameBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        nameBox.addView(label(c.base, 17, TEXT, true))
        nameBox.addView(label(if (c.meme) "MEME WATCHLIST" else "SPOT / USDT", 9, MUTED, true))
        row.addView(nameBox)
        val scoreColor = if (c.score >= 75) GREEN else if (c.score >= 55) GOLD else MUTED
        row.addView(label("${c.score.toInt()}/100", 16, scoreColor, true))
        card.addView(row)
        card.addView(space(10))
        val priceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        priceRow.addView(label("${fmt.format(c.price)} USDT", 14, TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        priceRow.addView(label("24ч ${signed(c.h24)}%", 12, if (c.h24 >= 0) GREEN else RED, true))
        card.addView(priceRow)
        card.addView(space(10))
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metrics.addView(metric("1Ч", signed(c.h1) + "%", c.h1 >= 0), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("4Ч", signed(c.h4) + "%", c.h4 >= 0), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("RSI", num.format(c.rsi), c.rsi in 45.0..70.0), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("ОБЪЁМ", "x${num.format(c.volumeRatio)}", c.volumeRatio >= 1.5), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(metrics)
        card.addView(space(8))
        card.addView(label("Тренд EMA 9/21: ${if (c.trendUp) "ВВЕРХ ↑" else "НЕ ПОДТВЕРЖДЁН"}   •   Объём 24ч: ${compact(c.volume24)} USDT", 10, if (c.trendUp) GREEN else MUTED, false))
        return card
    }

    private fun metric(caption: String, value: String, positive: Boolean): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(label(caption, 9, MUTED, true))
        box.addView(label(value, 12, if (positive) GREEN else RED, true))
        return box
    }

    private fun tabButton(text: String, action: () -> Unit) = Button(this).apply { this.text = text; isAllCaps = false; textSize = 12f; setOnClickListener { action() } }
    private fun updateTabs() {
        if (!::allTab.isInitialized) return
        allTab.setTextColor(if (!showMemes) BG else TEXT); allTab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (!showMemes) GREEN else PANEL2))
        memeTab.setTextColor(if (showMemes) BG else TEXT); memeTab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (showMemes) GREEN else PANEL2))
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun signed(v: Double) = (if (v >= 0) "+" else "") + num.format(v)
    private fun compact(v: Double): String = when { v >= 1e9 -> "${num.format(v / 1e9)}B"; v >= 1e6 -> "${num.format(v / 1e6)}M"; v >= 1e3 -> "${num.format(v / 1e3)}K"; else -> num.format(v) }
    private fun pct(a: Double, b: Double) = if (b == 0.0) 0.0 else (a / b - 1.0) * 100.0
    private fun ema(values: List<Double>, period: Int): Double { if (values.size < period) return 0.0; val alpha = 2.0 / (period + 1.0); var current = values.take(period).average(); for (v in values.drop(period)) current = alpha * v + (1 - alpha) * current; return current }
    private fun rsi(values: List<Double>, period: Int): Double {
        if (values.size < period + 1) return 50.0
        val changes = values.zipWithNext { a, b -> b - a }.takeLast(period)
        val gain = changes.map { max(it, 0.0) }.average(); val loss = changes.map { max(-it, 0.0) }.average()
        if (loss == 0.0) return if (gain > 0) 100.0 else 50.0
        val rs = gain / loss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    private fun get(path: String): String {
        val connection = (URL("https://data-api.binance.vision$path").openConnection() as HttpURLConnection)
        connection.requestMethod = "GET"; connection.connectTimeout = 12000; connection.readTimeout = 15000
        try { val code = connection.responseCode; val stream = if (code in 200..299) connection.inputStream else connection.errorStream; val body = stream.bufferedReader().use { it.readText() }; if (code !in 200..299) throw IllegalStateException("HTTP $code"); return body } finally { connection.disconnect() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Сигналы сканера", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "Высокие рейтинги при ручном сканировании" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 40)
    }
    private fun notifyTopSignals(signals: List<CoinSignal>) {
        if (signals.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val body = signals.joinToString("\n") { "${it.base}: ${it.score.toInt()}/100 • 24ч ${signed(it.h24)}%" }
        val notification = android.app.Notification.Builder(this, CHANNEL_ID)
        notification.setSmallIcon(android.R.drawable.stat_notify_sync_noanim).setContentTitle("Binance Scanner PRO: сильные сигналы").setContentText("Найдено ${signals.size} монет с рейтингом 80+").setStyle(android.app.Notification.BigTextStyle().bigText(body)).setAutoCancel(true)
        manager.notify(101, notification.build())
    }

    override fun onDestroy() { super.onDestroy(); executor.shutdownNow() }
}
